System.register(["@angular/core", "@NoyauFonctionnel/service"], function (exports_1, context_1) {
    "use strict";
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __moduleName = context_1 && context_1.id;
    var core_1, service_1, htmlTemplate, ListeChoses;
    return {
        setters: [
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (service_1_1) {
                service_1 = service_1_1;
            }
        ],
        execute: function () {
            //import {window} from "rxjs/operator/window";
            htmlTemplate = `
	<section class="todoapp">
		<header class="header">
			<h1>{{titre}}</h1>
			<div class="topButtons">
			    <button class="read" (click)="readAll()"></button>
                <button class="listen" (click)="start()"></button>
                <span class="messageVoice">{{getVoiceStatus()}}</span>
			</div>
			<form (submit)="ajouterChose(newTodo.value)">
				<input class="new-todo" placeholder="Que faire ?" autofocus #newTodo>
			</form>
		</header>
		<section class="main">
			<input  class="toggle-all" 
			        type="checkbox"
			        (change)="changerTout(all.checked)"
			#all/>
            
			<label for="toggle-all">Mark all as complete</label>
			<ul class="todo-list">
			    <li [class.editing]="compo.editing" [class.completed]="chose.fait" *ngFor="let chose of getChoses()">
                    <item-chose
                        [nf]="chose"
                        #compo></item-chose>
                </li>
            </ul>
		</section>
        <footer class="footer">
            <span class="todo-count"><strong>{{getRestant()}}</strong> restantes</span>
            <ul class="filters">
                <li (click) = "currentFilter = filterAll">
                    <a class="filterAll"  [class.selected] = "currentFilter === filterAll">Tous</a>
                </li>
                <li (click) = "currentFilter = filterUndone">
                    <a class="filterActives"  [class.selected] = "currentFilter === filterUndone">Actifs</a>
                </li>
                <li (click) = "currentFilter = filterDone">
                    <a class="filterCompleted" [class.selected] = "currentFilter === filterDone">Complétés</a>
                </li>
            </ul>
            <button class="clear-completed" (click) = "deleteCompleted()">Supprimer cochées</button>
        </footer>
	</section>
	<hr/>
	<section>
	    <section *ngFor="let chose of getChoses()">
	        {{chose.fait}} : {{chose.texte}}
        </section>
	</section>
	<hr>
	<p class="legend">Possible avec la reconaissance vocale:</p>
	<p>Pour ajouter une tache dire: "ajouter [Nom de la tache]"</p>
	<p>Pour supprimer une tache dire: "supprimer [Nom de la tache]"</p>
	<p>Pour supprimer les taches cochées dire: "supprimer cochées"</p>
	<p>Pour cocher une tache dire: "cocher [Nom de la tache]"</p>
	<p>Pour décocher une tache dire: "décocher [Nom de la tache]"</p>
	<p>Pour avoir le statut d'une tache  dire: "statut [Nom de la tache]"</p>
	<p>Pour afficher par statut dire: "afficher [tous | actifs | complétés]"</p>
	<p>Pour tout cocher dire: "tout cocher"</p>
	<p>Pour tout décocher dire: "tout décocher"</p>
	<p>Pour connaitre le nombre de tâches restantes dire: "tâches restantes"</p>
`;
            ListeChoses = class ListeChoses {
                constructor(serviceListe) {
                    this.serviceListe = serviceListe;
                    this.choses = [];
                    this.voiceStatus = "";
                    this.filterAll = () => true;
                    this.filterDone = (c) => c.fait;
                    this.filterUndone = (c) => !c.fait;
                    this.currentFilter = this.filterAll;
                }
                ;
                /** *
                 * ngOnInit(): initialise la liste de chose
                 * */
                ngOnInit() {
                    service_1.ListeChosesService.getData().then((nf) => {
                        this.nf = nf;
                        this.choses = nf.choses;
                    });
                }
                /** *
                 * getChoses(): retourne la liste de chose selon le filtre activé
                 * return: chose[]
                 * */
                getChoses() {
                    return this.choses.filter(this.currentFilter);
                }
                /** *
                 * ajouterChose(): ajoute une tâche avec comme texte la string en paramêtre
                 * */
                ajouterChose(texte) {
                    this.nf.Ajouter(texte);
                }
                /** *
                 * changerTout(): change l'état de toutes les tâches selon le booléen
                 * */
                changerTout(isChecked) {
                    for (let chose of this.choses) {
                        chose.fait = isChecked;
                    }
                }
                /** *
                 * deleteCompleted(): supprime les tâches faites
                 * */
                deleteCompleted() {
                    this.choses.filter(this.filterDone).forEach(c => c.dispose());
                }
                /** *
                 * getRestant(): retourne le nombre de tâches à faire
                 * return: int
                 * */
                getRestant() {
                    return this.choses.filter(this.filterUndone).length;
                }
                /** *
                 * readAll(): lit en synthèse vocale toutes les tâches
                 * */
                readAll() {
                    for (let chose of this.choses) {
                        var synth = window.speechSynthesis;
                        var phraseADire = new SpeechSynthesisUtterance(chose.texte);
                        synth.speak(phraseADire);
                    }
                }
                /** *
                 * start(): récupère ce qui est dit au micro et effectue les changements dans la todo liste
                 * */
                start() {
                    var recognition = new webkitSpeechRecognition();
                    var phraseEntendu;
                    recognition.start();
                    /* Quand webkitSpeechRecognition reconnait une voix */
                    recognition.onresult = (event) => {
                        /* stocke la phrase entendu */
                        phraseEntendu = event.results[0][0].transcript;
                        /* On met tout en minuscule */
                        phraseEntendu = phraseEntendu.toLowerCase();
                    };
                    /* On attend 5 secondes avant de faire l'action sur la todo liste */
                    setTimeout(() => {
                        if ((phraseEntendu !== "") && (phraseEntendu !== undefined)) {
                            /* Mise à jour de l'affichage si le système à bien entendu */
                            this.voiceStatus = "J'ai entendu: " + phraseEntendu;
                            /* On sépare la phrase reconnue en tableau de mot */
                            var splitted = phraseEntendu.split(" ");
                            /* Reconnaissance de mots clés et action en conséquence */
                            if (splitted["0"] === "ajouter") {
                                /* on enlève le premier mot de la phrase */
                                var AAjouter = phraseEntendu.substring(8);
                                this.ajouterChose(AAjouter);
                            }
                            else if (splitted["0"] === "supprimer") {
                                if ((splitted["1"] == "coché") || (splitted["1"] == "couché") || (splitted["1"] == "cocher") || (splitted["1"] == "coucher")) {
                                    this.deleteCompleted();
                                }
                                else {
                                    var ASupprimer = phraseEntendu.substring(10);
                                    for (let chose of this.choses) {
                                        if (chose.texte === ASupprimer) {
                                            chose.dispose();
                                        }
                                    }
                                }
                            }
                            else if ((splitted["0"] === "coucher") || (splitted["0"] === "cocher")) {
                                /* on enlève le premier mot de la phrase */
                                var ACocher = phraseEntendu.substring(8);
                                console.log(phraseEntendu);
                                for (let chose of this.choses) {
                                    if (chose.texte === ACocher) {
                                        chose.Fait(true);
                                    }
                                }
                            }
                            else if (splitted["0"] === "décocher") {
                                /* on enlève le premier mot de la phrase */
                                var ADeCocher = phraseEntendu.substring(9);
                                for (let chose of this.choses) {
                                    if (chose.texte === ADeCocher) {
                                        chose.Fait(false);
                                    }
                                }
                            }
                            else if ((splitted["0"] === "status") || (splitted["0"] === "statue") || (splitted["0"] === "statut")) {
                                /* on enlève le premier mot de la phrase */
                                var ADonnerStatus = phraseEntendu.substring(7);
                                for (let chose of this.choses) {
                                    if (chose.texte === ADonnerStatus) {
                                        var contenu;
                                        if (chose.fait) {
                                            contenu = "la tache est faite";
                                        }
                                        else {
                                            contenu = "la tache n'est pas faite";
                                        }
                                        var synth = window.speechSynthesis;
                                        var phraseADire = new SpeechSynthesisUtterance(contenu);
                                        synth.speak(phraseADire);
                                    }
                                }
                            }
                            else if ((splitted["0"] === "afficher") || (splitted["0"] === "affiché")) {
                                if ((splitted["1"] === "tous") || (splitted["1"] === "tout") || (splitted["1"] === "toute")) {
                                    this.currentFilter = this.filterAll;
                                }
                                else if ((splitted["1"] === "actif") || (splitted["1"] === "active")) {
                                    this.currentFilter = this.filterUndone;
                                }
                                else if ((splitted["1"] === "complété") || (splitted["1"] === "compléter")) {
                                    this.currentFilter = this.filterDone;
                                }
                            }
                            else if ((splitted["0"] === "tous") || (splitted["0"] === "tout")) {
                                if ((splitted["1"] == "coché") || (splitted["1"] == "couché") || (splitted["1"] == "cocher") || (splitted["1"] == "coucher")) {
                                    this.changerTout(true);
                                }
                                else if ((splitted["1"] == "décocher") || (splitted["1"] == "décoché")) {
                                    this.changerTout(false);
                                }
                            }
                            else if (((splitted["0"] === "tâche") || (splitted["0"] === "tâches")) && ((splitted["1"] === "restante") || (splitted["1"] === "restant"))) {
                                var synth = window.speechSynthesis;
                                var phraseADire = new SpeechSynthesisUtterance(this.getRestant() + " tâches restantes");
                                synth.speak(phraseADire);
                            }
                        }
                        else {
                            this.voiceStatus = "je n'ai pas bien entendu";
                        }
                    }, 5000);
                }
                /*
                * getVoiceStatus(): retourne le status de la reconaissance vocale, soit la phrase entendue, soit "je n'ai pas bien entendu"
                * return: string
                * */
                getVoiceStatus() {
                    return this.voiceStatus;
                }
            };
            __decorate([
                core_1.Input(),
                __metadata("design:type", String)
            ], ListeChoses.prototype, "titre", void 0);
            ListeChoses = __decorate([
                core_1.Component({
                    selector: "liste-choses",
                    template: htmlTemplate
                }),
                __metadata("design:paramtypes", [service_1.ListeChosesService])
            ], ListeChoses);
            exports_1("ListeChoses", ListeChoses);
        }
    };
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHMvTGlzdGVDaG9zZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFHQSw4Q0FBOEM7WUFFeEMsWUFBWSxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQThEcEIsQ0FBQztZQVFXLFdBQVcsR0FBeEI7Z0JBWUMsWUFBc0IsWUFBZ0M7b0JBQWhDLGlCQUFZLEdBQVosWUFBWSxDQUFvQjtvQkFSM0MsV0FBTSxHQUFjLEVBQUUsQ0FBQztvQkFDdkIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7b0JBRWpDLGNBQVMsR0FBWSxNQUFNLElBQUksQ0FBQztvQkFDaEMsZUFBVSxHQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7b0JBQ3BDLGlCQUFZLEdBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUN2QyxrQkFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBR2xDLENBQUM7Z0JBQUEsQ0FBQztnQkFFQzs7cUJBRUs7Z0JBQ0wsUUFBUTtvQkFDSiw0QkFBa0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUUsQ0FBQyxFQUFFO3dCQUNsQyxJQUFJLENBQUMsRUFBRSxHQUFPLEVBQUUsQ0FBQzt3QkFDakIsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDO29CQUM1QixDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO2dCQUVEOzs7cUJBR0s7Z0JBQ0wsU0FBUztvQkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDO2dCQUVEOztxQkFFSztnQkFDTCxZQUFZLENBQUMsS0FBYTtvQkFDdEIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNCLENBQUM7Z0JBRUQ7O3FCQUVLO2dCQUNMLFdBQVcsQ0FBQyxTQUFrQjtvQkFDMUIsR0FBRyxDQUFBLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7d0JBQzFCLEtBQUssQ0FBQyxJQUFJLEdBQUMsU0FBUyxDQUFDO29CQUN6QixDQUFDO2dCQUNMLENBQUM7Z0JBRUQ7O3FCQUVLO2dCQUNMLGVBQWU7b0JBQ1gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0JBQ2hFLENBQUM7Z0JBRUQ7OztxQkFHSztnQkFDTCxVQUFVO29CQUNOLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUN4RCxDQUFDO2dCQUVEOztxQkFFSztnQkFDTCxPQUFPO29CQUNILEdBQUcsQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3dCQUM1QixJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDO3dCQUNuQyxJQUFJLFdBQVcsR0FBRyxJQUFJLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDNUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDN0IsQ0FBQztnQkFDTCxDQUFDO2dCQUVEOztxQkFFSztnQkFDTCxLQUFLO29CQUNELElBQUksV0FBVyxHQUFHLElBQUksdUJBQXVCLEVBQUUsQ0FBQztvQkFDaEQsSUFBSSxhQUFhLENBQUM7b0JBQ2xCLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFFcEIsc0RBQXNEO29CQUN0RCxXQUFXLENBQUMsUUFBUSxHQUFJLENBQUMsS0FBSzt3QkFFMUIsOEJBQThCO3dCQUM5QixhQUFhLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7d0JBRS9DLDhCQUE4Qjt3QkFDOUIsYUFBYSxHQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDOUMsQ0FBQyxDQUFDO29CQUVGLG9FQUFvRTtvQkFDcEUsVUFBVSxDQUFDO3dCQUNQLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFMUQsNkRBQTZEOzRCQUM3RCxJQUFJLENBQUMsV0FBVyxHQUFHLGdCQUFnQixHQUFHLGFBQWEsQ0FBQzs0QkFFcEQsb0RBQW9EOzRCQUNwRCxJQUFJLFFBQVEsR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUV4QywwREFBMEQ7NEJBQzFELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dDQUU5QiwyQ0FBMkM7Z0NBQzNDLElBQUksUUFBUSxHQUFHLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBRWhDLENBQUM7NEJBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUN2QyxFQUFFLENBQUEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxPQUFPLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxRQUFRLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxRQUFRLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFBLENBQUM7b0NBQzNHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQ0FDM0IsQ0FBQztnQ0FBQSxJQUFJLENBQUMsQ0FBQztvQ0FDSCxJQUFJLFVBQVUsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO29DQUM3QyxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzt3Q0FDNUIsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDOzRDQUM3QixLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7d0NBQ3BCLENBQUM7b0NBQ0wsQ0FBQztnQ0FDTCxDQUFDOzRCQUNMLENBQUM7NEJBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FFdkUsMkNBQTJDO2dDQUMzQyxJQUFJLE9BQU8sR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dDQUMzQixHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztvQ0FDNUIsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDO3dDQUMxQixLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29DQUNyQixDQUFDO2dDQUNMLENBQUM7NEJBQ0wsQ0FBQzs0QkFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUM7Z0NBRXRDLDJDQUEyQztnQ0FDM0MsSUFBSSxTQUFTLEdBQUcsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDM0MsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0NBQzVCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQzt3Q0FDNUIsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQ0FDdEIsQ0FBQztnQ0FDTCxDQUFDOzRCQUNMLENBQUM7NEJBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FFdEcsMkNBQTJDO2dDQUMzQyxJQUFJLGFBQWEsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUMvQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztvQ0FDNUIsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxhQUFhLENBQUMsQ0FBQyxDQUFDO3dDQUNoQyxJQUFJLE9BQU8sQ0FBQzt3Q0FDWixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs0Q0FDYixPQUFPLEdBQUcsb0JBQW9CLENBQUM7d0NBQ25DLENBQUM7d0NBQUMsSUFBSSxDQUFDLENBQUM7NENBQ0osT0FBTyxHQUFHLDBCQUEwQixDQUFDO3dDQUN6QyxDQUFDO3dDQUVELElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7d0NBQ25DLElBQUksV0FBVyxHQUFHLElBQUksd0JBQXdCLENBQUMsT0FBTyxDQUFDLENBQUM7d0NBQ3hELEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7b0NBQzdCLENBQUM7Z0NBQ0wsQ0FBQzs0QkFDTCxDQUFDOzRCQUFDLElBQUksQ0FBQyxFQUFFLENBQUEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBRyxVQUFVLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFBLENBQUM7Z0NBQzdELEVBQUUsQ0FBQSxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFHLE1BQU0sQ0FBQyxJQUFFLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFHLE1BQU0sQ0FBQyxJQUFFLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUEsQ0FBQztvQ0FDOUUsSUFBSSxDQUFDLGFBQWEsR0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO2dDQUV0QyxDQUFDO2dDQUFBLElBQUksQ0FBQyxFQUFFLENBQUEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBRyxPQUFPLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFBLENBQUM7b0NBQzVELElBQUksQ0FBQyxhQUFhLEdBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQ0FFekMsQ0FBQztnQ0FBQSxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUcsVUFBVSxDQUFDLElBQUUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQSxDQUFDO29DQUNsRSxJQUFJLENBQUMsYUFBYSxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7Z0NBQ3ZDLENBQUM7NEJBQ1QsQ0FBQzs0QkFBQyxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUcsTUFBTSxDQUFDLElBQUUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQSxDQUFDO2dDQUMxRCxFQUFFLENBQUEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxPQUFPLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxRQUFRLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxRQUFRLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQzVHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7Z0NBRTNCLENBQUM7Z0NBQUEsSUFBSSxDQUFDLEVBQUUsQ0FBQSxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFFLFVBQVUsQ0FBQyxJQUFFLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUEsQ0FBQztvQ0FDOUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQ0FDNUIsQ0FBQzs0QkFDTCxDQUFDOzRCQUFBLElBQUksQ0FBQyxFQUFFLENBQUEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFHLE9BQU8sQ0FBQyxJQUFFLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFHLFFBQVEsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBRyxVQUFVLENBQUMsSUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUEsQ0FBQztnQ0FDM0gsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQztnQ0FDbkMsSUFBSSxXQUFXLEdBQUcsSUFBSSx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEdBQUMsbUJBQW1CLENBQUMsQ0FBQztnQ0FDdEYsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDN0IsQ0FBQzt3QkFDTCxDQUFDO3dCQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNKLElBQUksQ0FBQyxXQUFXLEdBQUcsMEJBQTBCLENBQUM7d0JBQ2xELENBQUM7b0JBQ0wsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNaLENBQUM7Z0JBRUQ7OztvQkFHSTtnQkFDSixjQUFjO29CQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUM1QixDQUFDO2FBQ0osQ0FBQTtZQS9MWTtnQkFBUixZQUFLLEVBQUU7O3NEQUFnQjtZQUZmLFdBQVc7Z0JBTHZCLGdCQUFTLENBQUM7b0JBQ1QsUUFBUSxFQUFJLGNBQWM7b0JBQzFCLFFBQVEsRUFBSSxZQUFZO2lCQUN6QixDQUFDO2lEQWNtQyw0QkFBa0I7ZUFaMUMsV0FBVyxDQWlNdkI7O1FBR0QsQ0FBQyIsImZpbGUiOiJjb21wb25lbnRzL0xpc3RlQ2hvc2VzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIElucHV0LCBPbkluaXQsIEluamVjdGFibGUsIE5nWm9uZX0gICAgICAgICAgICAgICBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHtDaG9zZSwgTGlzdGVDaG9zZXMgYXMgTGlzdGVDaG9zZXNORn0gXHRmcm9tIFwiQE5veWF1Rm9uY3Rpb25uZWwvbmZcIjtcbmltcG9ydCB7TGlzdGVDaG9zZXNTZXJ2aWNlfSAgICAgICAgICAgICAgICAgICAgIGZyb20gXCJATm95YXVGb25jdGlvbm5lbC9zZXJ2aWNlXCI7XG4vL2ltcG9ydCB7d2luZG93fSBmcm9tIFwicnhqcy9vcGVyYXRvci93aW5kb3dcIjtcblxuY29uc3QgaHRtbFRlbXBsYXRlID0gYFxuXHQ8c2VjdGlvbiBjbGFzcz1cInRvZG9hcHBcIj5cblx0XHQ8aGVhZGVyIGNsYXNzPVwiaGVhZGVyXCI+XG5cdFx0XHQ8aDE+e3t0aXRyZX19PC9oMT5cblx0XHRcdDxkaXYgY2xhc3M9XCJ0b3BCdXR0b25zXCI+XG5cdFx0XHQgICAgPGJ1dHRvbiBjbGFzcz1cInJlYWRcIiAoY2xpY2spPVwicmVhZEFsbCgpXCI+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImxpc3RlblwiIChjbGljayk9XCJzdGFydCgpXCI+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtZXNzYWdlVm9pY2VcIj57e2dldFZvaWNlU3RhdHVzKCl9fTwvc3Bhbj5cblx0XHRcdDwvZGl2PlxuXHRcdFx0PGZvcm0gKHN1Ym1pdCk9XCJham91dGVyQ2hvc2UobmV3VG9kby52YWx1ZSlcIj5cblx0XHRcdFx0PGlucHV0IGNsYXNzPVwibmV3LXRvZG9cIiBwbGFjZWhvbGRlcj1cIlF1ZSBmYWlyZSA/XCIgYXV0b2ZvY3VzICNuZXdUb2RvPlxuXHRcdFx0PC9mb3JtPlxuXHRcdDwvaGVhZGVyPlxuXHRcdDxzZWN0aW9uIGNsYXNzPVwibWFpblwiPlxuXHRcdFx0PGlucHV0ICBjbGFzcz1cInRvZ2dsZS1hbGxcIiBcblx0XHRcdCAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcblx0XHRcdCAgICAgICAgKGNoYW5nZSk9XCJjaGFuZ2VyVG91dChhbGwuY2hlY2tlZClcIlxuXHRcdFx0I2FsbC8+XG4gICAgICAgICAgICBcblx0XHRcdDxsYWJlbCBmb3I9XCJ0b2dnbGUtYWxsXCI+TWFyayBhbGwgYXMgY29tcGxldGU8L2xhYmVsPlxuXHRcdFx0PHVsIGNsYXNzPVwidG9kby1saXN0XCI+XG5cdFx0XHQgICAgPGxpIFtjbGFzcy5lZGl0aW5nXT1cImNvbXBvLmVkaXRpbmdcIiBbY2xhc3MuY29tcGxldGVkXT1cImNob3NlLmZhaXRcIiAqbmdGb3I9XCJsZXQgY2hvc2Ugb2YgZ2V0Q2hvc2VzKClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGl0ZW0tY2hvc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZl09XCJjaG9zZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAjY29tcG8+PC9pdGVtLWNob3NlPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICA8L3VsPlxuXHRcdDwvc2VjdGlvbj5cbiAgICAgICAgPGZvb3RlciBjbGFzcz1cImZvb3RlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0b2RvLWNvdW50XCI+PHN0cm9uZz57e2dldFJlc3RhbnQoKX19PC9zdHJvbmc+IHJlc3RhbnRlczwvc3Bhbj5cbiAgICAgICAgICAgIDx1bCBjbGFzcz1cImZpbHRlcnNcIj5cbiAgICAgICAgICAgICAgICA8bGkgKGNsaWNrKSA9IFwiY3VycmVudEZpbHRlciA9IGZpbHRlckFsbFwiPlxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImZpbHRlckFsbFwiICBbY2xhc3Muc2VsZWN0ZWRdID0gXCJjdXJyZW50RmlsdGVyID09PSBmaWx0ZXJBbGxcIj5Ub3VzPC9hPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgPGxpIChjbGljaykgPSBcImN1cnJlbnRGaWx0ZXIgPSBmaWx0ZXJVbmRvbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJmaWx0ZXJBY3RpdmVzXCIgIFtjbGFzcy5zZWxlY3RlZF0gPSBcImN1cnJlbnRGaWx0ZXIgPT09IGZpbHRlclVuZG9uZVwiPkFjdGlmczwvYT5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIDxsaSAoY2xpY2spID0gXCJjdXJyZW50RmlsdGVyID0gZmlsdGVyRG9uZVwiPlxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImZpbHRlckNvbXBsZXRlZFwiIFtjbGFzcy5zZWxlY3RlZF0gPSBcImN1cnJlbnRGaWx0ZXIgPT09IGZpbHRlckRvbmVcIj5Db21wbMOpdMOpczwvYT5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJjbGVhci1jb21wbGV0ZWRcIiAoY2xpY2spID0gXCJkZWxldGVDb21wbGV0ZWQoKVwiPlN1cHByaW1lciBjb2Now6llczwvYnV0dG9uPlxuICAgICAgICA8L2Zvb3Rlcj5cblx0PC9zZWN0aW9uPlxuXHQ8aHIvPlxuXHQ8c2VjdGlvbj5cblx0ICAgIDxzZWN0aW9uICpuZ0Zvcj1cImxldCBjaG9zZSBvZiBnZXRDaG9zZXMoKVwiPlxuXHQgICAgICAgIHt7Y2hvc2UuZmFpdH19IDoge3tjaG9zZS50ZXh0ZX19XG4gICAgICAgIDwvc2VjdGlvbj5cblx0PC9zZWN0aW9uPlxuXHQ8aHI+XG5cdDxwIGNsYXNzPVwibGVnZW5kXCI+UG9zc2libGUgYXZlYyBsYSByZWNvbmFpc3NhbmNlIHZvY2FsZTo8L3A+XG5cdDxwPlBvdXIgYWpvdXRlciB1bmUgdGFjaGUgZGlyZTogXCJham91dGVyIFtOb20gZGUgbGEgdGFjaGVdXCI8L3A+XG5cdDxwPlBvdXIgc3VwcHJpbWVyIHVuZSB0YWNoZSBkaXJlOiBcInN1cHByaW1lciBbTm9tIGRlIGxhIHRhY2hlXVwiPC9wPlxuXHQ8cD5Qb3VyIHN1cHByaW1lciBsZXMgdGFjaGVzIGNvY2jDqWVzIGRpcmU6IFwic3VwcHJpbWVyIGNvY2jDqWVzXCI8L3A+XG5cdDxwPlBvdXIgY29jaGVyIHVuZSB0YWNoZSBkaXJlOiBcImNvY2hlciBbTm9tIGRlIGxhIHRhY2hlXVwiPC9wPlxuXHQ8cD5Qb3VyIGTDqWNvY2hlciB1bmUgdGFjaGUgZGlyZTogXCJkw6ljb2NoZXIgW05vbSBkZSBsYSB0YWNoZV1cIjwvcD5cblx0PHA+UG91ciBhdm9pciBsZSBzdGF0dXQgZCd1bmUgdGFjaGUgIGRpcmU6IFwic3RhdHV0IFtOb20gZGUgbGEgdGFjaGVdXCI8L3A+XG5cdDxwPlBvdXIgYWZmaWNoZXIgcGFyIHN0YXR1dCBkaXJlOiBcImFmZmljaGVyIFt0b3VzIHwgYWN0aWZzIHwgY29tcGzDqXTDqXNdXCI8L3A+XG5cdDxwPlBvdXIgdG91dCBjb2NoZXIgZGlyZTogXCJ0b3V0IGNvY2hlclwiPC9wPlxuXHQ8cD5Qb3VyIHRvdXQgZMOpY29jaGVyIGRpcmU6IFwidG91dCBkw6ljb2NoZXJcIjwvcD5cblx0PHA+UG91ciBjb25uYWl0cmUgbGUgbm9tYnJlIGRlIHTDomNoZXMgcmVzdGFudGVzIGRpcmU6IFwidMOiY2hlcyByZXN0YW50ZXNcIjwvcD5cbmA7XG5cbnR5cGUgZmlsdGVyQ2hvc2UgPSAoYyA6IENob3NlKSA9PiBib29sZWFuO1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yXHRcdDogXCJsaXN0ZS1jaG9zZXNcIixcbiAgdGVtcGxhdGVcdFx0OiBodG1sVGVtcGxhdGVcbn0pXG5cbmV4cG9ydCBjbGFzcyBMaXN0ZUNob3NlcyBpbXBsZW1lbnRzIE9uSW5pdCB7XG5cbiAgICBASW5wdXQoKSB0aXRyZVx0OiBzdHJpbmc7XG4gICAgcHVibGljIG5mICAgICAgIDogTGlzdGVDaG9zZXNORjtcbiAgICBwcml2YXRlIGNob3NlcyAgOiBDaG9zZVtdID0gW107XG4gICAgcHJpdmF0ZSB2b2ljZVN0YXR1cyAgOiBzdHJpbmc9XCJcIjtcblxuICAgIGZpbHRlckFsbCA6IEZJTFRFUiA9ICgpID0+IHRydWU7XG4gICAgZmlsdGVyRG9uZSA6IEZJTFRFUiA9IChjKSA9PiBjLmZhaXQ7XG4gICAgZmlsdGVyVW5kb25lIDogRklMVEVSID0gKGMpID0+ICFjLmZhaXQ7XG4gICAgY3VycmVudEZpbHRlciA9IHRoaXMuZmlsdGVyQWxsO1xuXG5cdGNvbnN0cnVjdG9yXHRcdChwcml2YXRlIHNlcnZpY2VMaXN0ZTogTGlzdGVDaG9zZXNTZXJ2aWNlKSB7XG5cdH07XG5cbiAgICAvKiogKlxuICAgICAqIG5nT25Jbml0KCk6IGluaXRpYWxpc2UgbGEgbGlzdGUgZGUgY2hvc2VcbiAgICAgKiAqL1xuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICBMaXN0ZUNob3Nlc1NlcnZpY2UuZ2V0RGF0YSgpLnRoZW4oIChuZikgPT4ge1xuICAgICAgICAgICAgdGhpcy5uZiAgICAgPSBuZjtcbiAgICAgICAgICAgIHRoaXMuY2hvc2VzID0gbmYuY2hvc2VzO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKiogKlxuICAgICAqIGdldENob3NlcygpOiByZXRvdXJuZSBsYSBsaXN0ZSBkZSBjaG9zZSBzZWxvbiBsZSBmaWx0cmUgYWN0aXbDqVxuICAgICAqIHJldHVybjogY2hvc2VbXVxuICAgICAqICovXG4gICAgZ2V0Q2hvc2VzKCkgOiBDaG9zZVtdIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hvc2VzLmZpbHRlcih0aGlzLmN1cnJlbnRGaWx0ZXIpO1xuICAgIH1cblxuICAgIC8qKiAqXG4gICAgICogYWpvdXRlckNob3NlKCk6IGFqb3V0ZSB1bmUgdMOiY2hlIGF2ZWMgY29tbWUgdGV4dGUgbGEgc3RyaW5nIGVuIHBhcmFtw6p0cmVcbiAgICAgKiAqL1xuICAgIGFqb3V0ZXJDaG9zZSh0ZXh0ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMubmYuQWpvdXRlcih0ZXh0ZSk7XG4gICAgfVxuXG4gICAgLyoqICpcbiAgICAgKiBjaGFuZ2VyVG91dCgpOiBjaGFuZ2UgbCfDqXRhdCBkZSB0b3V0ZXMgbGVzIHTDomNoZXMgc2Vsb24gbGUgYm9vbMOpZW5cbiAgICAgKiAqL1xuICAgIGNoYW5nZXJUb3V0KGlzQ2hlY2tlZDogYm9vbGVhbikge1xuICAgICAgICBmb3IobGV0IGNob3NlIG9mIHRoaXMuY2hvc2VzKXtcbiAgICAgICAgICAgIGNob3NlLmZhaXQ9aXNDaGVja2VkO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqICpcbiAgICAgKiBkZWxldGVDb21wbGV0ZWQoKTogc3VwcHJpbWUgbGVzIHTDomNoZXMgZmFpdGVzXG4gICAgICogKi9cbiAgICBkZWxldGVDb21wbGV0ZWQoKSB7XG4gICAgICAgIHRoaXMuY2hvc2VzLmZpbHRlcih0aGlzLmZpbHRlckRvbmUpLmZvckVhY2goYz0+Yy5kaXNwb3NlKCkpO1xuICAgIH1cblxuICAgIC8qKiAqXG4gICAgICogZ2V0UmVzdGFudCgpOiByZXRvdXJuZSBsZSBub21icmUgZGUgdMOiY2hlcyDDoCBmYWlyZVxuICAgICAqIHJldHVybjogaW50XG4gICAgICogKi9cbiAgICBnZXRSZXN0YW50KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jaG9zZXMuZmlsdGVyKHRoaXMuZmlsdGVyVW5kb25lKS5sZW5ndGg7XG4gICAgfVxuXG4gICAgLyoqICpcbiAgICAgKiByZWFkQWxsKCk6IGxpdCBlbiBzeW50aMOoc2Ugdm9jYWxlIHRvdXRlcyBsZXMgdMOiY2hlc1xuICAgICAqICovXG4gICAgcmVhZEFsbCgpIHtcbiAgICAgICAgZm9yIChsZXQgY2hvc2Ugb2YgdGhpcy5jaG9zZXMpIHtcbiAgICAgICAgICAgIHZhciBzeW50aCA9IHdpbmRvdy5zcGVlY2hTeW50aGVzaXM7XG4gICAgICAgICAgICB2YXIgcGhyYXNlQURpcmUgPSBuZXcgU3BlZWNoU3ludGhlc2lzVXR0ZXJhbmNlKGNob3NlLnRleHRlKTtcbiAgICAgICAgICAgIHN5bnRoLnNwZWFrKHBocmFzZUFEaXJlKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKiAqXG4gICAgICogc3RhcnQoKTogcsOpY3Vww6hyZSBjZSBxdWkgZXN0IGRpdCBhdSBtaWNybyBldCBlZmZlY3R1ZSBsZXMgY2hhbmdlbWVudHMgZGFucyBsYSB0b2RvIGxpc3RlXG4gICAgICogKi9cbiAgICBzdGFydCgpIHtcbiAgICAgICAgdmFyIHJlY29nbml0aW9uID0gbmV3IHdlYmtpdFNwZWVjaFJlY29nbml0aW9uKCk7XG4gICAgICAgIHZhciBwaHJhc2VFbnRlbmR1O1xuICAgICAgICByZWNvZ25pdGlvbi5zdGFydCgpO1xuXG4gICAgICAgIC8qIFF1YW5kIHdlYmtpdFNwZWVjaFJlY29nbml0aW9uIHJlY29ubmFpdCB1bmUgdm9peCAqL1xuICAgICAgICByZWNvZ25pdGlvbi5vbnJlc3VsdCA9ICAoZXZlbnQpID0+IHtcblxuICAgICAgICAgICAgLyogc3RvY2tlIGxhIHBocmFzZSBlbnRlbmR1ICovXG4gICAgICAgICAgICBwaHJhc2VFbnRlbmR1ID0gZXZlbnQucmVzdWx0c1swXVswXS50cmFuc2NyaXB0O1xuXG4gICAgICAgICAgICAvKiBPbiBtZXQgdG91dCBlbiBtaW51c2N1bGUgKi9cbiAgICAgICAgICAgIHBocmFzZUVudGVuZHU9cGhyYXNlRW50ZW5kdS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qIE9uIGF0dGVuZCA1IHNlY29uZGVzIGF2YW50IGRlIGZhaXJlIGwnYWN0aW9uIHN1ciBsYSB0b2RvIGxpc3RlICovXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKChwaHJhc2VFbnRlbmR1ICE9PSBcIlwiKSAmJiAocGhyYXNlRW50ZW5kdSAhPT0gdW5kZWZpbmVkKSkge1xuXG4gICAgICAgICAgICAgICAgLyogTWlzZSDDoCBqb3VyIGRlIGwnYWZmaWNoYWdlIHNpIGxlIHN5c3TDqG1lIMOgIGJpZW4gZW50ZW5kdSAqL1xuICAgICAgICAgICAgICAgIHRoaXMudm9pY2VTdGF0dXMgPSBcIkonYWkgZW50ZW5kdTogXCIgKyBwaHJhc2VFbnRlbmR1O1xuXG4gICAgICAgICAgICAgICAgLyogT24gc8OpcGFyZSBsYSBwaHJhc2UgcmVjb25udWUgZW4gdGFibGVhdSBkZSBtb3QgKi9cbiAgICAgICAgICAgICAgICB2YXIgc3BsaXR0ZWQgPSBwaHJhc2VFbnRlbmR1LnNwbGl0KFwiIFwiKTtcblxuICAgICAgICAgICAgICAgIC8qIFJlY29ubmFpc3NhbmNlIGRlIG1vdHMgY2zDqXMgZXQgYWN0aW9uIGVuIGNvbnPDqXF1ZW5jZSAqL1xuICAgICAgICAgICAgICAgIGlmIChzcGxpdHRlZFtcIjBcIl0gPT09IFwiYWpvdXRlclwiKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgLyogb24gZW5sw6h2ZSBsZSBwcmVtaWVyIG1vdCBkZSBsYSBwaHJhc2UgKi9cbiAgICAgICAgICAgICAgICAgICAgdmFyIEFBam91dGVyID0gcGhyYXNlRW50ZW5kdS5zdWJzdHJpbmcoOCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWpvdXRlckNob3NlKEFBam91dGVyKTtcblxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc3BsaXR0ZWRbXCIwXCJdID09PSBcInN1cHByaW1lclwiKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmKChzcGxpdHRlZFtcIjFcIl09PVwiY29jaMOpXCIpfHwoc3BsaXR0ZWRbXCIxXCJdPT1cImNvdWNow6lcIil8fChzcGxpdHRlZFtcIjFcIl09PVwiY29jaGVyXCIpfHwoc3BsaXR0ZWRbXCIxXCJdPT1cImNvdWNoZXJcIikpe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWxldGVDb21wbGV0ZWQoKTtcbiAgICAgICAgICAgICAgICAgICAgfWVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIEFTdXBwcmltZXIgPSBwaHJhc2VFbnRlbmR1LnN1YnN0cmluZygxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBjaG9zZSBvZiB0aGlzLmNob3Nlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaG9zZS50ZXh0ZSA9PT0gQVN1cHByaW1lcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaG9zZS5kaXNwb3NlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICgoc3BsaXR0ZWRbXCIwXCJdID09PSBcImNvdWNoZXJcIikgfHwgKHNwbGl0dGVkW1wiMFwiXSA9PT0gXCJjb2NoZXJcIikpIHtcblxuICAgICAgICAgICAgICAgICAgICAvKiBvbiBlbmzDqHZlIGxlIHByZW1pZXIgbW90IGRlIGxhIHBocmFzZSAqL1xuICAgICAgICAgICAgICAgICAgICB2YXIgQUNvY2hlciA9IHBocmFzZUVudGVuZHUuc3Vic3RyaW5nKDgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhwaHJhc2VFbnRlbmR1KTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgY2hvc2Ugb2YgdGhpcy5jaG9zZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaG9zZS50ZXh0ZSA9PT0gQUNvY2hlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNob3NlLkZhaXQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHNwbGl0dGVkW1wiMFwiXSA9PT0gXCJkw6ljb2NoZXJcIikge1xuXG4gICAgICAgICAgICAgICAgICAgIC8qIG9uIGVubMOodmUgbGUgcHJlbWllciBtb3QgZGUgbGEgcGhyYXNlICovXG4gICAgICAgICAgICAgICAgICAgIHZhciBBRGVDb2NoZXIgPSBwaHJhc2VFbnRlbmR1LnN1YnN0cmluZyg5KTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgY2hvc2Ugb2YgdGhpcy5jaG9zZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaG9zZS50ZXh0ZSA9PT0gQURlQ29jaGVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hvc2UuRmFpdChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKChzcGxpdHRlZFtcIjBcIl0gPT09IFwic3RhdHVzXCIpIHx8IChzcGxpdHRlZFtcIjBcIl0gPT09IFwic3RhdHVlXCIpIHx8IChzcGxpdHRlZFtcIjBcIl0gPT09IFwic3RhdHV0XCIpKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgLyogb24gZW5sw6h2ZSBsZSBwcmVtaWVyIG1vdCBkZSBsYSBwaHJhc2UgKi9cbiAgICAgICAgICAgICAgICAgICAgdmFyIEFEb25uZXJTdGF0dXMgPSBwaHJhc2VFbnRlbmR1LnN1YnN0cmluZyg3KTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgY2hvc2Ugb2YgdGhpcy5jaG9zZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaG9zZS50ZXh0ZSA9PT0gQURvbm5lclN0YXR1cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb250ZW51O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjaG9zZS5mYWl0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnUgPSBcImxhIHRhY2hlIGVzdCBmYWl0ZVwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnUgPSBcImxhIHRhY2hlIG4nZXN0IHBhcyBmYWl0ZVwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzeW50aCA9IHdpbmRvdy5zcGVlY2hTeW50aGVzaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBocmFzZUFEaXJlID0gbmV3IFNwZWVjaFN5bnRoZXNpc1V0dGVyYW5jZShjb250ZW51KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzeW50aC5zcGVhayhwaHJhc2VBRGlyZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYoKHNwbGl0dGVkW1wiMFwiXT09PVwiYWZmaWNoZXJcIil8fChzcGxpdHRlZFtcIjBcIl09PT1cImFmZmljaMOpXCIpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKChzcGxpdHRlZFtcIjFcIl09PT1cInRvdXNcIil8fChzcGxpdHRlZFtcIjFcIl09PT1cInRvdXRcIil8fChzcGxpdHRlZFtcIjFcIl09PT1cInRvdXRlXCIpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRGaWx0ZXI9dGhpcy5maWx0ZXJBbGw7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1lbHNlIGlmKChzcGxpdHRlZFtcIjFcIl09PT1cImFjdGlmXCIpfHwoc3BsaXR0ZWRbXCIxXCJdPT09XCJhY3RpdmVcIikpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudEZpbHRlcj10aGlzLmZpbHRlclVuZG9uZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2UgaWYoKHNwbGl0dGVkW1wiMVwiXT09PVwiY29tcGzDqXTDqVwiKXx8KHNwbGl0dGVkW1wiMVwiXT09PVwiY29tcGzDqXRlclwiKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50RmlsdGVyPXRoaXMuZmlsdGVyRG9uZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYoKHNwbGl0dGVkW1wiMFwiXT09PVwidG91c1wiKXx8KHNwbGl0dGVkW1wiMFwiXT09PVwidG91dFwiKSl7XG4gICAgICAgICAgICAgICAgICAgIGlmKChzcGxpdHRlZFtcIjFcIl09PVwiY29jaMOpXCIpfHwoc3BsaXR0ZWRbXCIxXCJdPT1cImNvdWNow6lcIil8fChzcGxpdHRlZFtcIjFcIl09PVwiY29jaGVyXCIpfHwoc3BsaXR0ZWRbXCIxXCJdPT1cImNvdWNoZXJcIikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlclRvdXQodHJ1ZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgfWVsc2UgaWYoKHNwbGl0dGVkW1wiMVwiXT09XCJkw6ljb2NoZXJcIil8fChzcGxpdHRlZFtcIjFcIl09PVwiZMOpY29jaMOpXCIpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlclRvdXQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfWVsc2UgaWYoKChzcGxpdHRlZFtcIjBcIl09PT1cInTDomNoZVwiKXx8KHNwbGl0dGVkW1wiMFwiXT09PVwidMOiY2hlc1wiKSkmJigoc3BsaXR0ZWRbXCIxXCJdPT09XCJyZXN0YW50ZVwiKXx8KHNwbGl0dGVkW1wiMVwiXT09PVwicmVzdGFudFwiKSkpe1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3ludGggPSB3aW5kb3cuc3BlZWNoU3ludGhlc2lzO1xuICAgICAgICAgICAgICAgICAgICB2YXIgcGhyYXNlQURpcmUgPSBuZXcgU3BlZWNoU3ludGhlc2lzVXR0ZXJhbmNlKHRoaXMuZ2V0UmVzdGFudCgpK1wiIHTDomNoZXMgcmVzdGFudGVzXCIpO1xuICAgICAgICAgICAgICAgICAgICBzeW50aC5zcGVhayhwaHJhc2VBRGlyZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLnZvaWNlU3RhdHVzID0gXCJqZSBuJ2FpIHBhcyBiaWVuIGVudGVuZHVcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSw1MDAwKTtcbiAgICB9XG5cbiAgICAvKlxuICAgICogZ2V0Vm9pY2VTdGF0dXMoKTogcmV0b3VybmUgbGUgc3RhdHVzIGRlIGxhIHJlY29uYWlzc2FuY2Ugdm9jYWxlLCBzb2l0IGxhIHBocmFzZSBlbnRlbmR1ZSwgc29pdCBcImplIG4nYWkgcGFzIGJpZW4gZW50ZW5kdVwiXG4gICAgKiByZXR1cm46IHN0cmluZ1xuICAgICogKi9cbiAgICBnZXRWb2ljZVN0YXR1cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudm9pY2VTdGF0dXM7XG4gICAgfVxufVxudHlwZSBGSUxURVIgPSAoYyA6IENob3NlKSA9PiBib29sZWFuO1xuXG4iXSwic291cmNlUm9vdCI6IiJ9
