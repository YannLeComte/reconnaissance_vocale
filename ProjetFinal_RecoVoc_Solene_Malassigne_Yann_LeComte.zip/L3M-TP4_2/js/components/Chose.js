System.register(["@angular/core", "@NoyauFonctionnel/nf"], function (exports_1, context_1) {
    "use strict";
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __moduleName = context_1 && context_1.id;
    var core_1, nf_1, htmlTemplate, ItemChose;
    return {
        setters: [
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (nf_1_1) {
                nf_1 = nf_1_1;
            }
        ],
        execute: function () {
            htmlTemplate = `
	<div class="view">
		<input 	class			= "toggle" 
				type			= "checkbox" 
				name			= "fait"
				[ngModel]="nf.fait"
				(change)="fait(inputFait.checked)"
				#inputFait/>
		<label 	class="texte"
		        (dblclick)="edit()"
				>{{nf.texte}}</label>
		<button class="destroy" (click)="dispose()"></button>
		<button class="read" (click)="read(nf.texte)"></button>
	</div>
	<form (submit)="setText(edittext.value)" *ngIf="editing">
		<input class= "edit"
		        [value]="nf.texte"
		        (focus)="editing"
		        (blur)="setText(edittext.value)"
		        #edittext/>
	</form>
`;
            ItemChose = class ItemChose {
                constructor() {
                    this.editing = false;
                }
                /** *
                 * dispose(): supprime la tâche
                 * */
                dispose() {
                    this.nf.dispose();
                }
                /** *
                 * fait(): change l'état de la chose avec le booléen en paramêtre
                 * */
                fait(fait) {
                    this.nf.Fait(fait);
                }
                /** *
                 * edit(): passe en mode édition
                 * */
                edit() {
                    this.editing = true;
                }
                /** *
                 * setText(): le texte de la tâche prend la valeur du paramêtre
                 * */
                setText(text) {
                    this.editing = false;
                    this.nf.Texte(text);
                }
                /** *
                 * read(): Lit la tâche qui est en paramêtre
                 * */
                read(tacheContenu) {
                    var synth = window.speechSynthesis;
                    var phraseADire = new SpeechSynthesisUtterance(tacheContenu);
                    synth.speak(phraseADire);
                }
            };
            __decorate([
                core_1.Input("nf"),
                __metadata("design:type", nf_1.Chose)
            ], ItemChose.prototype, "nf", void 0);
            __decorate([
                core_1.ViewChild("newText"),
                __metadata("design:type", core_1.ElementRef)
            ], ItemChose.prototype, "newTextInput", void 0);
            ItemChose = __decorate([
                core_1.Component({
                    selector: "item-chose",
                    template: htmlTemplate
                })
            ], ItemChose);
            exports_1("ItemChose", ItemChose);
        }
    };
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHMvQ2hvc2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFHTSxZQUFZLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCcEIsQ0FBQztZQU1XLFNBQVMsR0FBdEI7Z0JBSkE7b0JBT0MsWUFBTyxHQUFtQixLQUFLLENBQUM7Z0JBdUNqQyxDQUFDO2dCQXJDRzs7cUJBRUs7Z0JBQ0wsT0FBTztvQkFDSCxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN0QixDQUFDO2dCQUVEOztxQkFFSztnQkFDTCxJQUFJLENBQUMsSUFBWTtvQkFDYixJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdkIsQ0FBQztnQkFFRDs7cUJBRUs7Z0JBQ0wsSUFBSTtvQkFDQSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDeEIsQ0FBQztnQkFFRDs7cUJBRUs7Z0JBQ0wsT0FBTyxDQUFDLElBQVc7b0JBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN4QixDQUFDO2dCQUVEOztxQkFFSztnQkFDTCxJQUFJLENBQUMsWUFBb0I7b0JBQ2pCLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7b0JBQ25DLElBQUksV0FBVyxHQUFHLElBQUksd0JBQXdCLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQzdELEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2pDLENBQUM7YUFDSixDQUFBO1lBekNrQjtnQkFBZCxZQUFLLENBQUUsSUFBSSxDQUFFOzBDQUFRLFVBQUs7aURBQUM7WUFDVDtnQkFBckIsZ0JBQVMsQ0FBQyxTQUFTLENBQUM7MENBQWdCLGlCQUFVOzJEQUFDO1lBRnBDLFNBQVM7Z0JBSnJCLGdCQUFTLENBQUM7b0JBQ1QsUUFBUSxFQUFJLFlBQVk7b0JBQ3hCLFFBQVEsRUFBSSxZQUFZO2lCQUN6QixDQUFDO2VBQ1csU0FBUyxDQTBDckI7O1FBQ0QsQ0FBQyIsImZpbGUiOiJjb21wb25lbnRzL0Nob3NlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgVmlld0NoaWxkLCBFbGVtZW50UmVmfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHtDaG9zZX0gZnJvbSBcIkBOb3lhdUZvbmN0aW9ubmVsL25mXCI7XG5cbmNvbnN0IGh0bWxUZW1wbGF0ZSA9IGBcblx0PGRpdiBjbGFzcz1cInZpZXdcIj5cblx0XHQ8aW5wdXQgXHRjbGFzc1x0XHRcdD0gXCJ0b2dnbGVcIiBcblx0XHRcdFx0dHlwZVx0XHRcdD0gXCJjaGVja2JveFwiIFxuXHRcdFx0XHRuYW1lXHRcdFx0PSBcImZhaXRcIlxuXHRcdFx0XHRbbmdNb2RlbF09XCJuZi5mYWl0XCJcblx0XHRcdFx0KGNoYW5nZSk9XCJmYWl0KGlucHV0RmFpdC5jaGVja2VkKVwiXG5cdFx0XHRcdCNpbnB1dEZhaXQvPlxuXHRcdDxsYWJlbCBcdGNsYXNzPVwidGV4dGVcIlxuXHRcdCAgICAgICAgKGRibGNsaWNrKT1cImVkaXQoKVwiXG5cdFx0XHRcdD57e25mLnRleHRlfX08L2xhYmVsPlxuXHRcdDxidXR0b24gY2xhc3M9XCJkZXN0cm95XCIgKGNsaWNrKT1cImRpc3Bvc2UoKVwiPjwvYnV0dG9uPlxuXHRcdDxidXR0b24gY2xhc3M9XCJyZWFkXCIgKGNsaWNrKT1cInJlYWQobmYudGV4dGUpXCI+PC9idXR0b24+XG5cdDwvZGl2PlxuXHQ8Zm9ybSAoc3VibWl0KT1cInNldFRleHQoZWRpdHRleHQudmFsdWUpXCIgKm5nSWY9XCJlZGl0aW5nXCI+XG5cdFx0PGlucHV0IGNsYXNzPSBcImVkaXRcIlxuXHRcdCAgICAgICAgW3ZhbHVlXT1cIm5mLnRleHRlXCJcblx0XHQgICAgICAgIChmb2N1cyk9XCJlZGl0aW5nXCJcblx0XHQgICAgICAgIChibHVyKT1cInNldFRleHQoZWRpdHRleHQudmFsdWUpXCJcblx0XHQgICAgICAgICNlZGl0dGV4dC8+XG5cdDwvZm9ybT5cbmA7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3Rvclx0XHQ6IFwiaXRlbS1jaG9zZVwiLFxuICB0ZW1wbGF0ZVx0XHQ6IGh0bWxUZW1wbGF0ZVxufSlcbmV4cG9ydCBjbGFzcyBJdGVtQ2hvc2Uge1xuICAgIEBJbnB1dCAoXCJuZlwiICkgbmYgICA6IENob3NlO1xuXHRAVmlld0NoaWxkKFwibmV3VGV4dFwiKSBuZXdUZXh0SW5wdXQgOiBFbGVtZW50UmVmO1xuXHRlZGl0aW5nXHRcdFx0ICAgIDogYm9vbGVhbiA9IGZhbHNlO1xuXG4gICAgLyoqICpcbiAgICAgKiBkaXNwb3NlKCk6IHN1cHByaW1lIGxhIHTDomNoZVxuICAgICAqICovXG4gICAgZGlzcG9zZSgpIHtcbiAgICAgICAgdGhpcy5uZi5kaXNwb3NlKCk7XG4gICAgfVxuXG4gICAgLyoqICpcbiAgICAgKiBmYWl0KCk6IGNoYW5nZSBsJ8OpdGF0IGRlIGxhIGNob3NlIGF2ZWMgbGUgYm9vbMOpZW4gZW4gcGFyYW3DqnRyZVxuICAgICAqICovXG4gICAgZmFpdChmYWl0OmJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5uZi5GYWl0KGZhaXQpO1xuICAgIH1cblxuICAgIC8qKiAqXG4gICAgICogZWRpdCgpOiBwYXNzZSBlbiBtb2RlIMOpZGl0aW9uXG4gICAgICogKi9cbiAgICBlZGl0KCkge1xuICAgICAgICB0aGlzLmVkaXRpbmcgPSB0cnVlO1xuICAgIH1cblxuICAgIC8qKiAqXG4gICAgICogc2V0VGV4dCgpOiBsZSB0ZXh0ZSBkZSBsYSB0w6JjaGUgcHJlbmQgbGEgdmFsZXVyIGR1IHBhcmFtw6p0cmVcbiAgICAgKiAqL1xuICAgIHNldFRleHQodGV4dDpzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5lZGl0aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMubmYuVGV4dGUodGV4dCk7XG4gICAgfVxuXG4gICAgLyoqICpcbiAgICAgKiByZWFkKCk6IExpdCBsYSB0w6JjaGUgcXVpIGVzdCBlbiBwYXJhbcOqdHJlXG4gICAgICogKi9cbiAgICByZWFkKHRhY2hlQ29udGVudTogc3RyaW5nKSB7XG4gICAgICAgICAgICB2YXIgc3ludGggPSB3aW5kb3cuc3BlZWNoU3ludGhlc2lzO1xuICAgICAgICAgICAgdmFyIHBocmFzZUFEaXJlID0gbmV3IFNwZWVjaFN5bnRoZXNpc1V0dGVyYW5jZSh0YWNoZUNvbnRlbnUpO1xuICAgICAgICAgICAgc3ludGguc3BlYWsocGhyYXNlQURpcmUpO1xuICAgIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=
