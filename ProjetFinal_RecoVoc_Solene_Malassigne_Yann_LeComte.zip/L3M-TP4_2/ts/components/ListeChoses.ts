import {Component, Input, OnInit, Injectable, NgZone}               from "@angular/core";
import {Chose, ListeChoses as ListeChosesNF} 	from "@NoyauFonctionnel/nf";
import {ListeChosesService}                     from "@NoyauFonctionnel/service";
//import {window} from "rxjs/operator/window";

const htmlTemplate = `
	<section class="todoapp">
		<header class="header">
			<h1>{{titre}}</h1>
			<div class="topButtons">
			    <button class="read" (click)="readAll()"></button>
                <button class="listen" (click)="start()"></button>
                <span class="messageVoice">{{getVoiceStatus()}}</span>
			</div>
			<form (submit)="ajouterChose(newTodo.value)">
				<input class="new-todo" placeholder="Que faire ?" autofocus #newTodo>
			</form>
		</header>
		<section class="main">
			<input  class="toggle-all" 
			        type="checkbox"
			        (change)="changerTout(all.checked)"
			#all/>
            
			<label for="toggle-all">Mark all as complete</label>
			<ul class="todo-list">
			    <li [class.editing]="compo.editing" [class.completed]="chose.fait" *ngFor="let chose of getChoses()">
                    <item-chose
                        [nf]="chose"
                        #compo></item-chose>
                </li>
            </ul>
		</section>
        <footer class="footer">
            <span class="todo-count"><strong>{{getRestant()}}</strong> restantes</span>
            <ul class="filters">
                <li (click) = "currentFilter = filterAll">
                    <a class="filterAll"  [class.selected] = "currentFilter === filterAll">Tous</a>
                </li>
                <li (click) = "currentFilter = filterUndone">
                    <a class="filterActives"  [class.selected] = "currentFilter === filterUndone">Actifs</a>
                </li>
                <li (click) = "currentFilter = filterDone">
                    <a class="filterCompleted" [class.selected] = "currentFilter === filterDone">Complétés</a>
                </li>
            </ul>
            <button class="clear-completed" (click) = "deleteCompleted()">Supprimer cochées</button>
        </footer>
	</section>
	<hr/>
	<section>
	    <section *ngFor="let chose of getChoses()">
	        {{chose.fait}} : {{chose.texte}}
        </section>
	</section>
	<hr>
	<p class="legend">Possible avec la reconaissance vocale:</p>
	<p>Pour ajouter une tache dire: "ajouter [Nom de la tache]"</p>
	<p>Pour supprimer une tache dire: "supprimer [Nom de la tache]"</p>
	<p>Pour supprimer les taches cochées dire: "supprimer cochées"</p>
	<p>Pour cocher une tache dire: "cocher [Nom de la tache]"</p>
	<p>Pour décocher une tache dire: "décocher [Nom de la tache]"</p>
	<p>Pour avoir le statut d'une tache  dire: "statut [Nom de la tache]"</p>
	<p>Pour afficher par statut dire: "afficher [tous | actifs | complétés]"</p>
	<p>Pour tout cocher dire: "tout cocher"</p>
	<p>Pour tout décocher dire: "tout décocher"</p>
	<p>Pour connaitre le nombre de tâches restantes dire: "tâches restantes"</p>
`;

type filterChose = (c : Chose) => boolean;
@Component({
  selector		: "liste-choses",
  template		: htmlTemplate
})

export class ListeChoses implements OnInit {

    @Input() titre	: string;
    public nf       : ListeChosesNF;
    private choses  : Chose[] = [];
    private voiceStatus  : string="";

    filterAll : FILTER = () => true;
    filterDone : FILTER = (c) => c.fait;
    filterUndone : FILTER = (c) => !c.fait;
    currentFilter = this.filterAll;

	constructor		(private serviceListe: ListeChosesService) {
	};

    /** *
     * ngOnInit(): initialise la liste de chose
     * */
    ngOnInit(): void {
        ListeChosesService.getData().then( (nf) => {
            this.nf     = nf;
            this.choses = nf.choses;
        });
    }

    /** *
     * getChoses(): retourne la liste de chose selon le filtre activé
     * return: chose[]
     * */
    getChoses() : Chose[] {
        return this.choses.filter(this.currentFilter);
    }

    /** *
     * ajouterChose(): ajoute une tâche avec comme texte la string en paramêtre
     * */
    ajouterChose(texte: string) {
        this.nf.Ajouter(texte);
    }

    /** *
     * changerTout(): change l'état de toutes les tâches selon le booléen
     * */
    changerTout(isChecked: boolean) {
        for(let chose of this.choses){
            chose.fait=isChecked;
        }
    }

    /** *
     * deleteCompleted(): supprime les tâches faites
     * */
    deleteCompleted() {
        this.choses.filter(this.filterDone).forEach(c=>c.dispose());
    }

    /** *
     * getRestant(): retourne le nombre de tâches à faire
     * return: int
     * */
    getRestant() {
        return this.choses.filter(this.filterUndone).length;
    }

    /** *
     * readAll(): lit en synthèse vocale toutes les tâches
     * */
    readAll() {
        for (let chose of this.choses) {
            var synth = window.speechSynthesis;
            var phraseADire = new SpeechSynthesisUtterance(chose.texte);
            synth.speak(phraseADire);
        }
    }

    /** *
     * start(): récupère ce qui est dit au micro et effectue les changements dans la todo liste
     * */
    start() {
        var recognition = new webkitSpeechRecognition();
        var phraseEntendu;
        recognition.start();

        /* Quand webkitSpeechRecognition reconnait une voix */
        recognition.onresult =  (event) => {

            /* stocke la phrase entendu */
            phraseEntendu = event.results[0][0].transcript;

            /* On met tout en minuscule */
            phraseEntendu=phraseEntendu.toLowerCase();
        };

        /* On attend 5 secondes avant de faire l'action sur la todo liste */
        setTimeout(() => {
            if ((phraseEntendu !== "") && (phraseEntendu !== undefined)) {

                /* Mise à jour de l'affichage si le système à bien entendu */
                this.voiceStatus = "J'ai entendu: " + phraseEntendu;

                /* On sépare la phrase reconnue en tableau de mot */
                var splitted = phraseEntendu.split(" ");

                /* Reconnaissance de mots clés et action en conséquence */
                if (splitted["0"] === "ajouter") {

                    /* on enlève le premier mot de la phrase */
                    var AAjouter = phraseEntendu.substring(8);
                    this.ajouterChose(AAjouter);

                } else if (splitted["0"] === "supprimer") {
                    if((splitted["1"]=="coché")||(splitted["1"]=="couché")||(splitted["1"]=="cocher")||(splitted["1"]=="coucher")){
                        this.deleteCompleted();
                    }else {
                        var ASupprimer = phraseEntendu.substring(10);
                        for (let chose of this.choses) {
                            if (chose.texte === ASupprimer) {
                                chose.dispose();
                            }
                        }
                    }
                } else if ((splitted["0"] === "coucher") || (splitted["0"] === "cocher")) {

                    /* on enlève le premier mot de la phrase */
                    var ACocher = phraseEntendu.substring(8);
                    console.log(phraseEntendu);
                    for (let chose of this.choses) {
                        if (chose.texte === ACocher) {
                            chose.Fait(true);
                        }
                    }
                } else if (splitted["0"] === "décocher") {

                    /* on enlève le premier mot de la phrase */
                    var ADeCocher = phraseEntendu.substring(9);
                    for (let chose of this.choses) {
                        if (chose.texte === ADeCocher) {
                            chose.Fait(false);
                        }
                    }
                } else if ((splitted["0"] === "status") || (splitted["0"] === "statue") || (splitted["0"] === "statut")) {

                    /* on enlève le premier mot de la phrase */
                    var ADonnerStatus = phraseEntendu.substring(7);
                    for (let chose of this.choses) {
                        if (chose.texte === ADonnerStatus) {
                            var contenu;
                            if (chose.fait) {
                                contenu = "la tache est faite";
                            } else {
                                contenu = "la tache n'est pas faite";
                            }

                            var synth = window.speechSynthesis;
                            var phraseADire = new SpeechSynthesisUtterance(contenu);
                            synth.speak(phraseADire);
                        }
                    }
                } else if((splitted["0"]==="afficher")||(splitted["0"]==="affiché")){
                        if((splitted["1"]==="tous")||(splitted["1"]==="tout")||(splitted["1"]==="toute")){
                            this.currentFilter=this.filterAll;

                        }else if((splitted["1"]==="actif")||(splitted["1"]==="active")){
                            this.currentFilter=this.filterUndone;

                        }else if((splitted["1"]==="complété")||(splitted["1"]==="compléter")){
                            this.currentFilter=this.filterDone;
                        }
                } else if((splitted["0"]==="tous")||(splitted["0"]==="tout")){
                    if((splitted["1"]=="coché")||(splitted["1"]=="couché")||(splitted["1"]=="cocher")||(splitted["1"]=="coucher")) {
                        this.changerTout(true);

                    }else if((splitted["1"]=="décocher")||(splitted["1"]=="décoché")){
                        this.changerTout(false);
                    }
                }else if(((splitted["0"]==="tâche")||(splitted["0"]==="tâches"))&&((splitted["1"]==="restante")||(splitted["1"]==="restant"))){
                    var synth = window.speechSynthesis;
                    var phraseADire = new SpeechSynthesisUtterance(this.getRestant()+" tâches restantes");
                    synth.speak(phraseADire);
                }
            } else {
                this.voiceStatus = "je n'ai pas bien entendu";
            }
        },5000);
    }

    /*
    * getVoiceStatus(): retourne le status de la reconaissance vocale, soit la phrase entendue, soit "je n'ai pas bien entendu"
    * return: string
    * */
    getVoiceStatus() {
        return this.voiceStatus;
    }
}
type FILTER = (c : Chose) => boolean;

