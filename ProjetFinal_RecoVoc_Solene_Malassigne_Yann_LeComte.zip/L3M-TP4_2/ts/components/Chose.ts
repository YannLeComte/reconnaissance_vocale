import { Component, Input, ViewChild, ElementRef} from "@angular/core";
import {Chose} from "@NoyauFonctionnel/nf";

const htmlTemplate = `
	<div class="view">
		<input 	class			= "toggle" 
				type			= "checkbox" 
				name			= "fait"
				[ngModel]="nf.fait"
				(change)="fait(inputFait.checked)"
				#inputFait/>
		<label 	class="texte"
		        (dblclick)="edit()"
				>{{nf.texte}}</label>
		<button class="destroy" (click)="dispose()"></button>
		<button class="read" (click)="read(nf.texte)"></button>
	</div>
	<form (submit)="setText(edittext.value)" *ngIf="editing">
		<input class= "edit"
		        [value]="nf.texte"
		        (focus)="editing"
		        (blur)="setText(edittext.value)"
		        #edittext/>
	</form>
`;

@Component({
  selector		: "item-chose",
  template		: htmlTemplate
})
export class ItemChose {
    @Input ("nf" ) nf   : Chose;
	@ViewChild("newText") newTextInput : ElementRef;
	editing			    : boolean = false;

    /** *
     * dispose(): supprime la tâche
     * */
    dispose() {
        this.nf.dispose();
    }

    /** *
     * fait(): change l'état de la chose avec le booléen en paramêtre
     * */
    fait(fait:boolean) {
        this.nf.Fait(fait);
    }

    /** *
     * edit(): passe en mode édition
     * */
    edit() {
        this.editing = true;
    }

    /** *
     * setText(): le texte de la tâche prend la valeur du paramêtre
     * */
    setText(text:string) {
        this.editing = false;
        this.nf.Texte(text);
    }

    /** *
     * read(): Lit la tâche qui est en paramêtre
     * */
    read(tacheContenu: string) {
            var synth = window.speechSynthesis;
            var phraseADire = new SpeechSynthesisUtterance(tacheContenu);
            synth.speak(phraseADire);
    }
}
